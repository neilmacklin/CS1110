package a7tvbrands;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class A7TVBrands {

    public static void main(String[] args) throws FileNotFoundException {
        File theFile = new File("TVs.csv");
        Scanner inFile = new Scanner(theFile);
        File outputFile = new File("TVs.txt");
        PrintWriter p = new PrintWriter(outputFile);
        A7TVBrands call1 = new A7TVBrands();
        A7TVBrands call = new A7TVBrands();
        A7TVBrands call2 = new A7TVBrands();
        A7TVBrands call3 = new A7TVBrands();

        final int MAX_N = 100;
        int n;
        String line;
        String[] field = new String[5];
        // 1) create ARRAY of objects
        Television[] arrayOfTVs = new Television[MAX_N];

        //------------------------------------------------ FILL ARRAY from FILE
        int i = 0;
        boolean on;
        inFile.nextLine();
        while (inFile.hasNext()) {
            line = inFile.nextLine();
            field = line.split(",");
            arrayOfTVs[i] = new Television();
            arrayOfTVs[i].setManufacturer(field[0]);
            arrayOfTVs[i].setScreenSize(Integer.parseInt(field[1]));
            arrayOfTVs[i].setPowerOn(field[2]);
            arrayOfTVs[i].setChannel(Integer.parseInt(field[3]));
            arrayOfTVs[i].setVolume(Integer.parseInt(field[4]));
            i++;
        }

        n = i;
        int channelChange;
        int userChoice;
        call.PrintToScreen(arrayOfTVs, n, call2);
        Television caller = new Television();
        Television[] arrayOfTVsSort = Arrays.copyOf(arrayOfTVs, n);
        //user stuff --- calls the methods to use
        userChoice = Integer.parseInt(JOptionPane.showInputDialog("Enter 1"
                + " to add a TV.\nEnter 2 to search for a TV by "
                + "manufacturer.\nEnter 3 to "
                + "print to file.\nEnter 4 to turn the TV on or off.\n"
                + "Enter 5 to increase the volume of a TV.\n"
                + "Enter 6 to decrease the volume of a TV.\n"
                + "Enter 7 to change the channel of a TV.\n"
                + "Enter 8 to print to screen.\n"
                + "Enter 0 to exit."));
        int index = 0;
        while (userChoice != 0) {

            switch (userChoice) {
                case 1:
                    call1.AddNewTelevision(arrayOfTVs, n);
                    n++;
                    break;
                case 2:
                    call3.search(arrayOfTVsSort, n);
                    break;
                case 3:
                    call.PrintToFile(arrayOfTVs, n, call2, p);
                    break;
                case 4:
                    index = Integer.parseInt(JOptionPane.showInputDialog("Enter"
                            + " the index of the item you wish to change the "
                            + "power of."));
                    call2.SortMethod(arrayOfTVsSort, n);
                    arrayOfTVsSort[index].power();
                    break;
                case 5:
                    index = Integer.parseInt(JOptionPane.showInputDialog("Enter"
                            + " the index of the item you wish to increase the "
                            + "volume of."));
                    call2.SortMethod(arrayOfTVsSort, n);
                    arrayOfTVsSort[index].increaseVolume();
                    break;
                case 6:
                    index = Integer.parseInt(JOptionPane.showInputDialog("Enter"
                            + " the index of the item you wish to decrease the "
                            + "volume of."));
                    call2.SortMethod(arrayOfTVsSort, n);
                    arrayOfTVsSort[index].decreaseVolume();
                    break;
                case 7:
                    index = Integer.parseInt(JOptionPane.showInputDialog("Enter"
                            + " the index of the TV that you want to change "
                            + "the channel of."));
                    channelChange = Integer.parseInt(JOptionPane.
                            showInputDialog("Enter the channel you you to "
                                    + "change the tv to."));
                    call2.SortMethod(arrayOfTVsSort, n);
                    arrayOfTVsSort[index].setChannel(channelChange);
                    break;
                case 8:
                    call.PrintToScreen(arrayOfTVsSort, n, call2);
                    break;
                case 0:
                    //EXIT
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "INVALID...", 
                            "INVALID OPTION",
                            JOptionPane.WARNING_MESSAGE);
            }
            userChoice = Integer.parseInt(JOptionPane.showInputDialog("Enter 1"
                    + " to add a TV.\nEnter 2 to search for a TV by "
                    + "manufacturer.\nEnter 3 to "
                    + "print to file.\nEnter 4 to turn the TV on or off.\n"
                    + "Enter 5 to increase the volume of a TV.\n"
                    + "Enter 6 to decrease the volume of a TV.\n"
                    + "Enter 7 to change the channel of a TV.\n"
                    + "Enter 8 to print to screen.\n"
                    + "Enter 0 to exit."));
        }
        inFile.close();
        p.close();
    }//main method

    public void AddNewTelevision(Television[] arrayOfTVs, int n) {
        boolean tvOn;

        String manufacturer = JOptionPane.showInputDialog("Please enter a name "
                + "of a manufacturer.");
        int screenSize = Integer.parseInt(JOptionPane.showInputDialog("Please "
                + "enter the screen size."));
        String on = JOptionPane.showInputDialog("Enter 'yes' or 'no' if the "
                + "tv is on or not.");
        if (on.equalsIgnoreCase("yes")) {
            tvOn = true;
        } else {
            tvOn = false;
        }
        int channel = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "channel number."));
        int volume = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "volume number."));
        arrayOfTVs[n] = new Television();
        arrayOfTVs[n].setManufacturer(manufacturer);
        arrayOfTVs[n].setScreenSize(screenSize);
        arrayOfTVs[n].setPowerOn(on);
        arrayOfTVs[n].setChannel(channel);
        arrayOfTVs[n].setVolume(volume);
        n++;
//        arrayOfTVs[n] = new Television(manufacturer, screenSize, tvOn,
//                channel, volume);
    }

    public void SortMethod(Television[] arrayOfTVsSort, int n) {
        int iOfTempMin;
        int screen1;                            // for the field to compare
        int screen2;                            // for the field to compare

        for (int i = 0; i < n - 1; i++) {
            iOfTempMin = i;

            for (int index = i + 1; index < n; index++) {
                screen1 = arrayOfTVsSort[index].getScreenSize();
                screen2 = arrayOfTVsSort[iOfTempMin].getScreenSize();
                if (screen1 < screen2) {
                    iOfTempMin = index;
                }
            }
            swap(arrayOfTVsSort, i, iOfTempMin);
        }
    }

    private void swap(Television[] arrayOfTVsSort, int i1, int i2) {
        Television temp;
        temp = arrayOfTVsSort[i1];
        arrayOfTVsSort[i1] = arrayOfTVsSort[i2];
        arrayOfTVsSort[i2] = temp;
    }

    public void search(Television[] arrayOfTVsSort, int n) {
        String target = JOptionPane.showInputDialog("Enter a manufacturer");
        String manufacturer;
        System.out.println("Manufacturer  ScreenSize  PowerOn Channel Volume");
        for (int i = 0; i < n; i++) {
            manufacturer = arrayOfTVsSort[i].getManufacturer();
            if (manufacturer.compareToIgnoreCase(target) == 0) {
                System.out.printf("%-15s %5d %10b %5d %7d\n",
                        arrayOfTVsSort[i].getManufacturer(),
                        arrayOfTVsSort[i].getScreenSize(), arrayOfTVsSort[i]
                        .getPowerOn(),
                        arrayOfTVsSort[i].getChannel(), arrayOfTVsSort[i]
                        .getVolume());
            }

        }
    }

    public void PrintToScreen(Television[] arrayOfTVsSort, int n,
            A7TVBrands call2) {
        call2.SortMethod(arrayOfTVsSort, n);
        System.out.println("INDEX Manufacturer ScreenSize     PowerOn   Channel"
                + " Volume");
        for (int i = 0; i < n; i++) {
            System.out.printf("[%-1d]  %10s %8d %15b %8d %6d\n", i,
                    arrayOfTVsSort[i].getManufacturer(),
                    arrayOfTVsSort[i].getScreenSize(), arrayOfTVsSort[i]
                    .getPowerOn(),
                    arrayOfTVsSort[i].getChannel(), arrayOfTVsSort[i]
                    .getVolume());
        }
        System.out.println("-------------------------------------------------");
    }

    public void PrintToFile(Television[] arrayOfTVsSort, int n,
            A7TVBrands call2, PrintWriter p) {
        call2.SortMethod(arrayOfTVsSort, n);
        p.println("INDEX Manufacturer ScreenSize     PowerOn   Channel"
                + " Volume");
        for (int i = 0; i < n; i++) {
            p.printf("[%-1d]  %10s %8d %15b %8d %6d\n", i,
                    arrayOfTVsSort[i].getManufacturer(),
                    arrayOfTVsSort[i].getScreenSize(), arrayOfTVsSort[i]
                    .getPowerOn(),
                    arrayOfTVsSort[i].getChannel(), arrayOfTVsSort[i]
                    .getVolume());
        }
        p.println("-------------------------------------------------");
        p.close();
    }
}
