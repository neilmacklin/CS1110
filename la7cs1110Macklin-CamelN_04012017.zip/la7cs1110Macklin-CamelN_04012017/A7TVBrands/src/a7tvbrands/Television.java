
package a7tvbrands;


public class Television {
    private String Manufacturer;

    @Override
    public String toString() {
        return "Television{" + "Manufacturer=" + Manufacturer + ", ScreenSize=" 
                + ScreenSize + ", PowerOn=" + PowerOn + ", Channel=" + Channel 
                + ", Volume=" + Volume + '}';
    }
    private int ScreenSize;
    private boolean PowerOn;
    private int Channel;
    private int Volume;

// SETTERS
    public void setManufacturer(String Manufacturer) {
        this.Manufacturer = Manufacturer;
    }

    public void setScreenSize(int ScreenSize) {
        this.ScreenSize = ScreenSize;
    }

    public void setPowerOn(String PowerOn) {
        if ("false".equalsIgnoreCase(PowerOn) || "no".equalsIgnoreCase(PowerOn)) {
            this.PowerOn = false;
        } else {
            this.PowerOn = true;
        }
        
    }

    public void setChannel(int Channel) {
        
        this.Channel = Channel;
    }

    public void setVolume(int Volume) {
        this.Volume = Volume;
    }

// GETTERS
    public String getManufacturer() {
        return Manufacturer;
    }

    public int getScreenSize() {
        return ScreenSize;
    }

    public boolean getPowerOn() {
        return PowerOn;
    }

    public int getChannel() {
        return Channel;
    }

    public int getVolume() {
        return Volume;
    }
    
    public Television() {
        
    }//return new Television();
    
    public void power() {
        if (this.PowerOn != true) {
             this.PowerOn = true;
        } else {
            this.PowerOn = false;
        }
         
    }
    
    public void increaseVolume() {
        this.Volume++;
    }
    
    public void decreaseVolume() {
        if (this.Volume != 0) {
            this.Volume--;
        } else {
            this.Volume = 0;
        }
    }
    
    
}
