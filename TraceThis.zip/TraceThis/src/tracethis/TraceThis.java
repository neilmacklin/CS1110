/* PROJECT:  TraceThis
 * AUTHOR:  Dr. Kaminski
 * DESCRIPTION:  This does comparisons, looping, method calling & calculations.
 * TO DO:
 * 1) trace this code by hand to predict what x, y and z are at each point in
 *          the code.
 *                          ____X_______y_______z____
 *                      A   |       |       |       |
 *                      B   |       |       |       |
 *                      C   |       |       |       |
 *                      D   |       |       |       |
 *                      E   |       |       |       |
 *                      F   |       |       |       |
 *                      G   |       |       |       |
 *                          -------------------------
 *          AND WHAT WOULD PRINT:   ___________________________________________
 *                      
 * 2) use the INTERACTIVE DEBUGGER to examine what happens in the code.
 *****************************************************************************/
package tracethis;

public class TraceThis {

    public static void main(String[] args) {
        int x = 2;
        int y = 0;
        int z = 0;
                                    //   point A
        if (x <= 5) {
            y = x * x;
            z = z + y;
        }
                                    //   point B
        x++;
                                    //   point C
        if (x <= 4) {
            y = x * x + 1;
            z += y;
        }
                                    //   point D
        x += 1;
                                    //   point E
        while (x < 4) {
            y = x + x;
            z += y;
            x++;
        }
                                    //   point F       
        x = tripleIt(x);
                                    //   point G
        System.out.printf("x: %d, y: %d, z: %d\n", x, y, z); 
    }
    //-------------------------------------------------------------------------
    static int tripleIt(int num){
        int product = num * num;
        product = product * num;
        return product;
    }
}
