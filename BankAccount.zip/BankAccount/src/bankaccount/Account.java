/* OOP CLASS:  Account              USED BY PROJECT:  BankAccount
 * AUTHOR:  Dr. Kaminski (based on examples by Gaddis)
 * DESCRIPTION:  This demonstrates:
 *      - overloading to allow for double & String (i.e., user input) parameters
 *      - using "this" to designate instance variable
 *      - a constructor calling another constructor by using "this"
 *          (see constructor #3)
 *      - a "copy constructor" where an object is sent in as a parameter to
 *          copy from when creating the NEW object
 *      - an object as a parameter
 *      - equals utility method to compare if 2 objects are equal
 *          (i.e., all their instance variables' values match)
 *      - copy utility method to create a new object which is a copy of an
 *          existent object (i.e., with the exact same instance variable values)
 *****************************************************************************/
package bankaccount;
public class Account {
    //------------------------------------------------------ INSTANCE VARIABLES
    private double balance;
    private String owner;
    //---------------------------------------------------------- SETTER METHODS
    public void setBalance(double balance) { this.balance = balance; }
    public void setBalance(String balance) {
         this.balance = Double.parseDouble(balance);
    }
    public void setOwner (String owner) { this.owner = owner; }
    //---------------------------------------------------------- GETTER METHODS
    public double getBalance() { return balance; }
    public String getOwner()   { return owner;   }
    //---------------------------------------- 4 OVERLOADED CONSTRUCTOR METHODS
    //- - - - - - - - - - - - - - - - - - - - - - - -  1) "DEFAULT" CONSTRUCTOR
    //                                               (not used in this example)
    public Account() {
        balance = 0.0;
        owner = "TEMPORARY";
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - - 2) NORMAL CONSTRUCTOR
    public Account(double balance, String owner) {
        this.balance = balance;
        this.owner = owner;
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - 3) CALLS CONSTRUCTOR #2
    // uses "this" 
    //      - can only call a constructor from another constructor
    //              if both are in the SAME CLASS
    //      - the call MUST be the FIRST STATEMENT in the constructor method
    public Account(String startBalance, String owner) {
        this(Double.parseDouble(startBalance), owner);
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - 4) COPY CONSTRUCTOR
    //                                      parameter object must already exist
    public Account(Account acc) {
        balance = acc.getBalance();
        owner = acc.getOwner();
    }
    //--------------------------------------------- CORE PUBLIC SERVICE METHODS
    // Both are overloaded to handle double or String parameter
    public void deposit(double amount) {
        balance += amount;
        System.out.printf("\tOK, deposited $%.2f\n", amount);
    }
    public void deposit(String amount) {
        deposit(Double.parseDouble(amount));
    }
    public void withdraw(double amount) {
        balance -= amount;
        System.out.printf("\tOK, withdrew $%.2f\n", amount);
    }
    public void withdraw(String amount) {
        withdraw(Double.parseDouble(amount));
    }
    //--------------------------------------------------------- UTILITY METHODS
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  toString
    public String toString() {
        return String.format("%s's balance is $%,.2f", owner, balance); 
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  EQUALS
    // Is CURRENT object equal to PARAMETER object?
    //                              (i.e., their instance variables)
    public boolean equals(Account otherAcc) {
        String otherOwner = otherAcc.getOwner();
        double otherBal = otherAcc.getBalance();
        if (balance == otherBal && owner.compareToIgnoreCase(otherOwner) == 0)
            return true;
        return false;
    }
    public boolean equalsShorterVersion(Account otherAcc) {
        if (this.balance == otherAcc.getBalance()
                && this.owner.compareToIgnoreCase(otherAcc.getOwner()) == 0)
            return true;
        return false;
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  COPY
    // The CURRENT object's values stored in the NEW object's instance variables
    public Account copy() {
        Account differentAccount = new Account(balance,owner);
        return differentAccount;
    }
    public Account copyShorterVersion() {
        return new Account(balance,owner);
    }

    
    
    
    
}
