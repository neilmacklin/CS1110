/* PROJECT:  BankAccount
 * AUTHOR:  Dr. Kaminski (based on examples by Gaddis)
 * NOTE:  Data hardcoded here to simplify example.
 * DESCRIPTION:  This demonstrates:
 *      - several ways to DECLARE a new object
 *          1) normal declaration here in main
 *          2) call a local method - that method RETURNS the OBJECT
 *          3) call a special COPY method in the OOP class itself
 *              - which gives the NEW object the SAME VALUES as ORIGINAL object
 *          4) call COPY CONSTRUCTOR method in the OOP class
 *              - send in some OTHER object
 *              - so NEW object will get same values as that OTHER object
 *      - COMPARE 2 objects to see if they're equal
 *              - uses the OOP class's special EQUAL utility method
 *      - sending in objects as parameters
 *****************************************************************************/
package bankaccount;
public class BankAccount {

    public static void main(String[] args) {
        //*************************************************** DECLARE 4 OBJECTS
        
        //- - - - - - - - - - - - - - - - - - - - - - - - 1) NORMAL DECLARATION
        Account account1 = new Account(200.99, "Mary Doe");

        System.out.println("ACCOUNT 1:  " + account1);        // calls toString
        account1.deposit(200.00);       
        account1.withdraw(100.00);
        System.out.printf("\tBalance is now $%,.2f\n", account1.getBalance());
        
        //- - - - - - - - - - - - - - - - - - - - - - - -  2) CALL LOCAL METHOD
        //                                             which RETURNS the OBJECT
        Account account2 = makeNewObj();
        
        System.out.println("\nACCOUNT 2:  " + account2);      // calls toString
        account2.deposit("100.00");
        account2.withdraw("10.00");
        System.out.printf("\tBalance is now $%,.2f\n", account2.getBalance());
        
        Account account3 = makeNewObjShorterVersion();
        System.out.println("\nACCOUNT 3:  " + account3);
        
        //- - - - - - - - - - - - - - - - - -  3) CALL COPY METHOD IN OOP CLASS
        Account account4 = account1.copy();
        System.out.println("\nACCOUNT 4:  " + account4);
        
        Account account5 = account3.copyShorterVersion();
        System.out.println("\nACCOUNT 5:  " + account5);        
        
        //- - - - - - - - - - - - - - - - 4) CALL COPY CONSTRUCTOR IN OOP CLASS
        //                                    SENDING in an OBJECT to COPY FROM
        Account account6 = new Account(account2);       
        System.out.println("\nACCOUNT 6:  " + account6);

        //***************************************************** COMPARE OBJECTS
        System.out.print("\nCOMPARE ACCOUNTS 1 & 3");
        compare2Objects(account1, account3);

        System.out.print("\nCOMPARE ACCOUNTS 1 & 4");
        compare2Objects(account1, account4);
     
    } // END OF main METHOD 
    //*************************************************************************
    // Two versions to DECLARE another Account OBJECT
    //                  & return the new object (of Account class return type). 
    private static Account makeNewObj() {
        double startAmt = 200.00;
        String name = "Maria Gomez";
        Account newAccount = new Account(startAmt, name); // object declaration
        return newAccount;
    }
    private static Account makeNewObjShorterVersion() {
        return new Account(300.99, "Sanjay Ramesh");      // object declaration
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // COMPARE 2 objects by calling OOP class's EQUALS utility method.
    private static void compare2Objects(Account accA, Account accB) {
//        if (accA.equalsShorterVersion(accB))
        if (accA.equals(accB))
            System.out.printf(" - they ARE equal\n");
        else 
            System.out.printf(" - they are NOT equal\n");
        
        System.out.printf("\tbalances:  $%,.2f & $%,.2f\n\towners:  %s & %s\n",
                accA.getBalance(), accB.getBalance(),
                accA.getOwner(),   accB.getOwner());
    }
}
