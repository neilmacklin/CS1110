/*
*Neil Macklin - Camel
*CS 1110
*Assignment 6
* lab: 551
 */
package a6worldcapitaldistances;

import java.util.*;
import java.io.*;
import javax.swing.*;

public class A6WorldCapitalDistances {

    public static void main(String[] args) throws FileNotFoundException {
        File theFile = new File("WorldCapitals.csv");
        Scanner inFile = new Scanner(theFile);
        final int MAX_N = 300;
        String user;

        String field[] = new String[9];
        String array[] = new String[10000];
        String line;
        float lon1;
        float lon2;
        float lat1;
        float lat2;
        String countryName[] = new String[MAX_N];
        String capitalName[] = new String[MAX_N];
        float capitalLatitude[] = new float[MAX_N];
        float capitalLongitude[] = new float[MAX_N];
        String continentName[] = new String[MAX_N];

        int count = 0; // Number of lines and the number for the arrays
        inFile.nextLine();
        while (inFile.hasNext()) {
            line = inFile.nextLine();
            field = line.split(",");
            countryName[count] = field[0];
            capitalName[count] = field[1];
            capitalLatitude[count] = Float.parseFloat(field[2]);
            capitalLongitude[count] = Float.parseFloat(field[3]);
            continentName[count] = field[5];
            count++;
        }

        int counter = 0;
        int sizer = 0;
        //System.out.println(sizer);
        int size = (count * (count + 1) / 2 - count);
        int idxArr1[] = new int[size];
        int idxArr2[] = new int[size];
        double distArray[] = new double[size];
        String cityName[] = new String[size];
        
        for (int i = 0; i < count; i++) { 
            lat1 = capitalLatitude[i];
            lon1 = capitalLongitude[i];
            for (int j = i + 1; j < count ; j++ ) {
                cityName[counter] = capitalName[j]; // int j = i + 1 to not have
                                                    // repeat of values and + 1 
                idxArr1[counter] = i;               // to not compare the same 
                idxArr2[counter] = j;               // place.
                lat2 = capitalLatitude[j];
                lon2 = capitalLongitude[j];
                distArray[counter] = calcDistance(lat1, lat2, lon1, lon2);
                counter++;
            
            }
        }
        
        double sortedDistArray[] = Arrays.copyOf(distArray, size);
        int sortedIdxArr1[] = Arrays.copyOf(idxArr1, size);
        int sortedIdxArr2[] = Arrays.copyOf(idxArr2, size);
        String sortedCityName[] = Arrays.copyOf(cityName, size);
        sortArrays("sortedDistArray", sortedDistArray, sortedIdxArr1, sortedIdxArr2, 
                sortedCityName, size);
        printNicely("sorted by city name", sortedDistArray, sortedIdxArr1, 
                sortedIdxArr2, sortedCityName, size);
    }

    public static double calcDistance(float lat1, float lat2,
            float lon1, float lon2) {
        double dLon;
        double dLat;
        double a;
        double b;
        double answer;
        dLon = lon2 - lon1;
        dLat = lat2 - lat1;
        a = ((Math.sin(dLat / 2)) * (Math.sin(dLat / 2))) + Math.cos(lat1)
                * Math.cos(lat2) * ((Math.sin(dLon / 2)) * (Math.sin(dLon / 2)));
        b = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        answer = 3959 * b;
        return answer;
        
    }
    
    private static void swap(double sortedDistArray[], int sortedIdxArr1[], 
            int sortedIdxArr2[], String sortedCityName[], int i1, int i2) {
        String temp = sortedCityName[i1];
        sortedCityName[i1] = sortedCityName[i2];
        sortedCityName[i2] = temp;
        
        int tempInt = sortedIdxArr1[i1];
        sortedIdxArr1[i1] = sortedIdxArr1[i2];
        sortedIdxArr1[i2] = tempInt;
        
        tempInt = sortedIdxArr2[i1];
        sortedIdxArr2[i1] = sortedIdxArr2[i2];
        sortedIdxArr2[i2] = tempInt;
        
        double tempDouble = sortedDistArray[i1];
        sortedDistArray[i1] = sortedDistArray[i2];
        sortedDistArray[i2] = tempDouble;
    }
    
    public static void sortArrays(String sortKey, double sortedDistArray[], 
            int sortedIdxArr1[], int sortedIdxArr2[], String sortedCityName[], 
            int size) {
        int iOfTempMin;
        for (int i = 0; i < size - 1; i++) {
            iOfTempMin = i;           
            for (int index = i + 1; index < size; index++)        
                switch(sortKey) {
                    case("sortedCityName"):
                        if (sortedCityName[index].compareTo(sortedCityName
                                [iOfTempMin])<0)
                            iOfTempMin = index; 
                        break;
                    case("sortedIdxArr1"):
                        if (sortedIdxArr1[index]<sortedIdxArr1[iOfTempMin])
                            iOfTempMin = index; 
                        break;
                    case("sortedIdxArr2"):
                        if (sortedIdxArr2[index]<sortedIdxArr2[iOfTempMin])
                            iOfTempMin = index;
                        break;
                    case("sortedDistArray"):
                        if (sortedDistArray[index]<sortedDistArray[iOfTempMin])
                            iOfTempMin = index;
                        break;
                    default:
                        System.out.println("ERROR:  not a valid field name" +
                                "\n\tNo sort was done\n");
                        return;
                } // end of SWITCH
            swap(sortedDistArray, sortedIdxArr1, sortedIdxArr2, sortedCityName, 
                    i, iOfTempMin);
        } // end of outer FOR loop
    }
    
//    public static void NN(int size, double distArray[],
//            int idxArr1[], int idxArr2[], int count) {
//        double neighborsDist[] = new double[count];
//        double tempMin = Double.MAX_VALUE;
//        for (int i = 0; i < size; i++) {
//            
//            if (distArray[i] < tempMin) {
//                
//            }
//        }
//    }
    
    public static void printNicely(String sortKey, double sortedDistArray[], 
            int sortedIdxArr1[], int sortedIdxArr2[], String sortedCityName[], 
            int size) {
         System.out.println(sortKey);
        for(int i = 0; i < size; i++) {
            System.out.printf("[%d] %-20s %-10s %6d %,15.2f\n",
                    i, sortedCityName[i], sortedIdxArr1[i], sortedIdxArr2[i], 
                    sortedDistArray[i]);
        }    
        System.out.println("I have no idea how to search these parallel arrays"
                + " for the lowest of each country......");
        
    }
}
