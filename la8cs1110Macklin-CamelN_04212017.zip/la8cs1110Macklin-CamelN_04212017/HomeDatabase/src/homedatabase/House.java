

package homedatabase;
import java.util.*;
import javax.swing.*;
import java.io.*;

public class House {
    private String Address;
    private String City;
    private int SqFeet;
    private int Bedrooms;
    private int Price;
    
//CONSTRUCTOR-------------------------------------------------------------------
    public House(String Address, String City, int SqFeet, int Bedrooms, int Price) {
        this.Address = Address;
        this.City = City;
        this.SqFeet = SqFeet;
        this.Bedrooms = Bedrooms;
        this.Price = Price;
    }
    public House () {
        setAddress();
        setCity();
        setSqFeet();
        setBedrooms();
        setPrice();
    }


//SETTERS-----------------------------------------------------------------------  
    public void setAddress() {
        String address = JOptionPane.showInputDialog("Enter the address of the "
                + "house that you wish to add.");
        this.Address = address;
    }

    public void setCity() {
        String city = JOptionPane.showInputDialog("Enter the city that the "
                + "house is in.");
        this.City = city;
    }

    public void setSqFeet() {
        int sqFeet = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "square footage of the house."));
        if (sqFeet >= 100 && sqFeet <= 5000) {
            this.SqFeet = sqFeet;
        }
        else {
            JOptionPane.showMessageDialog(null, "ERROR! OUT OF RANGE. SQUARE "
                    + "FOOTAGE DEFAULTED TO 1500sqft");
            this.SqFeet = 1500;
        }
    }

    public void setBedrooms() {
        int bedrooms = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "amount of bedrooms the house has."));
        if (bedrooms >= 0 && bedrooms <= 5) {
            this.Bedrooms = bedrooms;
        }
        else {
            JOptionPane.showMessageDialog(null, "ERROR! OUT OF RANGE. DEFAULT "
                    + "TO 2 BEDROOMS.");
            this.Bedrooms = 2;
        }
        
    }

    public void setPrice() {
        int price = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "price of the house."));
        if (price >= 10000 && price <= 300000) {
            this.Price = price;
        }
        else {
            JOptionPane.showMessageDialog(null, "ERROR! OUT OF RANGE. DEFAULT "
                    + "TO $150,000");
            this.Price = 150000;
        }
        
    }

//GETTERS-----------------------------------------------------------------------    
    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public int getSqFeet() {
        return SqFeet;
    }

    public int getBedrooms() {
        return Bedrooms;
    }

    public int getPrice() {
        return Price;
    }
    
//PRINTING----------------------------------------------------------------------
    @Override
    public String toString () {
        return String.format("%s,%s,%d,%d,%d\n", Address, City, SqFeet, Bedrooms
                , Price);
    }
    
    public String prettyPrint(){
        return String.format("%-20s %-12s %,11d %10d     $%,7d\n", Address, City, 
                SqFeet, Bedrooms, Price);
    }
}
