
package homedatabase;

import java.io.*;
import java.util.*;
import javax.swing.*;
public class Utility {
    
    public static void loadFileToDB(ArrayList<House> list) throws FileNotFoundException{
        File f = new File("HouseDB.csv");
        Scanner inFile = new Scanner(f);
        String record;
        String[] field = new String[4];
        
        while (inFile.hasNext()) {
            record = inFile.nextLine();
            field = record.split(",");
            String address = field[0];
            String city = field[1];
            int sqFeet = Integer.parseInt(field[2]);
            int bedroom = Integer.parseInt(field[3]);
            int price = Integer.parseInt(field[4]);
            list.add(new House(address, city, sqFeet, bedroom, price));
        }
        inFile.close();   
    } 
    
    public static void dumpDBToFile(ArrayList<House> list) throws FileNotFoundException {
        File outputFile = new File("HouseDB.csv");
        PrintWriter p = new PrintWriter(outputFile);
        for (int i = 0; i < list.size(); i++) {
            p.printf(list.get(i).toString());
        }
        p.close();
    }    
}
