/*
Neil Macklin-Camel
CS 1110
Lab: 551
Assignment 8
*/
package homedatabase;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class HomeDatabase {

    
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<House> list = new <House>ArrayList();
        
        Utility.loadFileToDB(list);
        QueryHandler.listHouses(list);
        showMenu(list);
        Utility.dumpDBToFile(list);
    }
    
    public static void showMenu(ArrayList<House> list) {
        int userChoice = Integer.parseInt(JOptionPane.showInputDialog("Enter 1"
            + " to search by street address.\nEnter 2 to search by size"
            + " (SQUARE FOOTAGE).\nEnter 3 to search by number of "
            + "bedrooms.\nEnter 4 to list all the houses.\nEnter 5 to "
            + "add a new house.\nEnter 6 to remove a house.\nEnter 7 to be "
            + "done querying the database and exit."));
        while (userChoice != 7) {
            switch (userChoice) {
                case 1:
                    QueryHandler.doAddressSearch(list);
                    break;
                case 2:
                    QueryHandler.doSizeSearch(list);
                    break;
                case 3:
                    QueryHandler.doBRSearch(list);
                    break;
                case 4:
                    QueryHandler.listHouses(list);
                    break;
                case 5:
                    QueryHandler.addHouse(list);
                    break;
                case 6:
                    QueryHandler.removeHouse(list);
                    break;
                case 7:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "INVALID OPTION", 
                            "INVALID OPTION",
                            JOptionPane.WARNING_MESSAGE);
            }
        userChoice = Integer.parseInt(JOptionPane.showInputDialog("Enter 1"
            + " to search by street address.\nEnter 2 to search by size"
            + " (SQUARE FOOTAGE).\nEnter 3 to search by number of "
            + "bedrooms.\nEnter 4 to list all the houses.\nEnter 5 to "
            + "add a new house.\nEnter 6 to remove a house.\nEnter 7 to be "
            + "done querying the database and exit."));
        }
    }
    
    
    
}
