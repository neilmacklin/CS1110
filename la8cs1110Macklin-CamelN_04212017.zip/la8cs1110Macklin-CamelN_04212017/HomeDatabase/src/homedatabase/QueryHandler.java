
package homedatabase;

import java.util.*;
import javax.swing.*;
import java.io.*;
public class QueryHandler {
    
    public static void doAddressSearch(ArrayList<House> list){
        String target = JOptionPane.showInputDialog("Enter the address of the "
                + "house that you want to search.");
        String address;
        System.out.println("Address              City             Sq.Feet     "
                + " Bedrooms  Price ");
        for (int i = 0; i < list.size(); i++) {
            address = list.get(i).getAddress();
            if (address.compareToIgnoreCase(target) == 0) {
                System.out.printf(list.get(i).prettyPrint());
            }
        }
    }
    
    public static void doSizeSearch(ArrayList<House> list){
        int target = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "square footage of the house that you want to search."));
        int size;
        System.out.println("Address              City             Sq.Feet     "
                + " Bedrooms  Price ");
        for (int i = 0; i < list.size(); i++) {
            size = list.get(i).getSqFeet();
            if (size == target) {
                System.out.printf(list.get(i).prettyPrint());
            }
        }
    }
    
    public static void doBRSearch(ArrayList<House> list){
        int target = Integer.parseInt(JOptionPane.showInputDialog("Enter the "
                + "bedrooms of the house that you want to search."));
        int bedroom;
        System.out.println("Address              City             Sq.Feet     "
                + " Bedrooms  Price ");
        for (int i = 0; i < list.size(); i++) {
            bedroom = list.get(i).getBedrooms();
            if (bedroom == target) {
                System.out.printf(list.get(i).prettyPrint());
            }
        }
    }
    
    public static void listHouses(ArrayList<House> list){
        System.out.println("Address              City             Sq.Feet     "
                + " Bedrooms  Price ");
        for (int i = 0; i < list.size(); i++) {
            System.out.printf(list.get(i).prettyPrint());
        }
        System.out.println("--------------------------------------------------"
                + "----------------");
    }
    
    public static void addHouse(ArrayList<House> list){
        list.add(new House());
    }
    
    public static void removeHouse(ArrayList<House> list){
        String target = JOptionPane.showInputDialog("Enter the address of the "
                + "house that you want to remove.");
        String address;
        for (int i = 0; i < list.size(); i++) {
            address = list.get(i).getAddress();
            if (address.compareToIgnoreCase(target) == 0) {
                list.remove(i);
            }
        }
    }
    
}
